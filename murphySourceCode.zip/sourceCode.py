# Code for Murphy, UAT's tour guide robot
# Runs on a Raspberry Pi 3B+
# Written by Tyler Widener, Electrician/Programming Lead. tylerwidenerlm@gmail.com

# Current configuration has the following features:
# Motors + Motor Drivers
# Lights + Brake Lights
# Ultrasonic Sensors

# NOTES ON CONTROLLING MURPHY:
# Murphy can be fully controlled with the drive() function. Simply input the following for direction:
# 'F' = Forward
# 'R' = Turn Right
# 'L' = Turn Left
# 'B' = Reverse
# The distance traveled will be directly related to time, determined during testing.
# The time inputted MUST BE A MULTIPLE OF scanTime!!!
# For example, with scanTime set to 0.25, 5.0 is a valid time input, while 4.6 is not.
# Murphy will automatically shut down upon an invalid input.
# While driving, Murphy will automatically scan his surroundings every scanTime seconds.
# The DetectDist variables determine the maximum distance something needs to be from Murphy in order for him to stop
# until it is out of the way.
# forwardDetectDist is the detection distance for the forward sensor only.
# peripheralDetectDist is the detection distance for the right, left, and rear sensors.
# Units are in centimeters

# PROGRAM END HEADLIGHT CODES:
# Headlights flash twice:
#   Program Success
# Brake Lights flash twice:
#   Program Failure, Incorrect Time Input

#Libraries
import RPi.GPIO as GPIO
import time

#GPIO Mode (BOARD / BCM)
GPIO.setmode(GPIO.BCM)

#=====PINS=====
#Ultrasonic Sensors
F_US_Trig = 14
F_US_Echo = 15
B_US_Trig = 17
B_US_Echo = 23
L_US_Trig = 24
L_US_Echo = 25
R_US_Trig = 8
R_US_Echo = 7
#LEDs
L_Brake = 6
L_HLight = 16
R_Brake = 20
R_HLight = 21
#Motors
L_ForwardSignal = 13
L_ReverseSignal = 19
R_ForwardSignal = 12
R_ReverseSignal = 18

#Pin Setup
GPIO.setup(F_US_Trig, GPIO.OUT)
GPIO.setup(F_US_Echo, GPIO.IN)
GPIO.setup(B_US_Trig, GPIO.OUT)
GPIO.setup(B_US_Echo, GPIO.IN)
GPIO.setup(L_US_Trig, GPIO.OUT)
GPIO.setup(L_US_Echo, GPIO.IN)
GPIO.setup(R_US_Trig, GPIO.OUT)
GPIO.setup(R_US_Echo, GPIO.IN)
GPIO.setup(L_Brake, GPIO.OUT)
GPIO.setup(L_HLight, GPIO.OUT)
GPIO.setup(R_Brake, GPIO.OUT)
GPIO.setup(R_HLight, GPIO.OUT)
GPIO.setup(L_ForwardSignal, GPIO.OUT)
GPIO.setup(L_ReverseSignal, GPIO.OUT)
GPIO.setup(R_ForwardSignal, GPIO.OUT)
GPIO.setup(R_ReverseSignal, GPIO.OUT)

#Distancing Variables
F_Distance = 0.0
R_Distance = 0.0
L_Distance = 0.0
B_Distance = 0.0
forwardDetectDist = 50.0
peripheralDetectDist = 20.0
scanTime = 0.25

def drive(direction, travelTime): #Function for getting Murphy to drive
    print("Driving")
    #Safety for incorrect inputs
    if travelTime % scanTime != 0:
        endFailure()
        exit("Incorrect Time Input: " + travelTime)
    GPIO.output(L_HLight, GPIO.LOW)
    GPIO.output(R_HLight, GPIO.LOW)
    GPIO.output(L_Brake, GPIO.LOW)
    GPIO.output(R_Brake, GPIO.LOW)
    GPIO.output(L_ForwardSignal, GPIO.LOW)
    GPIO.output(R_ForwardSignal, GPIO.LOW)
    GPIO.output(L_ReverseSignal, GPIO.LOW)
    GPIO.output(R_ReverseSignal, GPIO.LOW)
    if (direction == 'F'):
        GPIO.output(L_HLight, GPIO.HIGH)
        GPIO.output(R_HLight, GPIO.HIGH)
        GPIO.output(L_ForwardSignal, GPIO.HIGH)
        GPIO.output(R_ForwardSignal, GPIO.HIGH)
        for x in range(0, travelTime, scanTime): #NOTE: If increment parameter is needed, add a third argument
            scan(direction, x, travelTime)
            time.sleep(scanTime)
    if (direction == 'R'):
        GPIO.output(L_HLight, GPIO.HIGH)
        GPIO.output(R_Brake, GPIO.HIGH)
        GPIO.output(L_ForwardSignal, GPIO.HIGH)
        GPIO.output(R_ReverseSignal, GPIO.HIGH)
        for x in range(0, travelTime, scanTime):
            scan(direction, x, travelTime)
            time.sleep(scanTime)
    if (direction == 'L'):
        GPIO.output(R_HLight, GPIO.HIGH)
        GPIO.output(L_Brake, GPIO.HIGH)
        GPIO.output(L_ReverseSignal, GPIO.HIGH)
        GPIO.output(R_ForwardSignal, GPIO.HIGH)
        for x in range(0, travelTime, scanTime):
            scan(direction, x, travelTime)
            time.sleep(scanTime)
    if (direction == 'B'):
        GPIO.output(L_Brake, GPIO.HIGH)
        GPIO.output(R_Brake, GPIO.HIGH)
        GPIO.output(L_ReverseSignal, GPIO.HIGH)
        GPIO.output(R_ReverseSignal, GPIO.HIGH)
        for x in range(0, travelTime, scanTime): #NOTE: If increment parameter is needed, add a third argument
            scan(direction, x, travelTime)
            time.sleep(scanTime)
    GPIO.output(L_HLight, GPIO.LOW)
    GPIO.output(R_HLight, GPIO.LOW)
    GPIO.output(L_Brake, GPIO.LOW)
    GPIO.output(R_Brake, GPIO.LOW)
    GPIO.output(L_ForwardSignal, GPIO.LOW)
    GPIO.output(R_ForwardSignal, GPIO.LOW)
    GPIO.output(L_ReverseSignal, GPIO.LOW)
    GPIO.output(R_ReverseSignal, GPIO.LOW)
    print("Drive Section Complete")

def distance(GPIO_TRIGGER, GPIO_ECHO): #Function for acquiring ultrasonic sensor distance
    # set Trigger to HIGH
    GPIO.output(GPIO_TRIGGER, True)

    # set Trigger after 0.01ms to LOW
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)

    StartTime = time.time()
    StopTime = time.time()

    # save StartTime
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()

    # save time of arrival
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()

    # time difference between start and arrival
    TimeElapsed = StopTime - StartTime
    # multiply with the sonic speed (34300 cm/s)
    # and divide by 2, because there and back
    distance = (TimeElapsed * 34300) / 2

    return distance

def stop(direction, traveledTime, targetTime): #Function for making Murphy stop until his surroundings are clear
    print("Stopping")
    GPIO.output(L_HLight, GPIO.HIGH)
    GPIO.output(R_HLight, GPIO.HIGH)
    GPIO.output(L_Brake, GPIO.HIGH)
    GPIO.output(R_Brake, GPIO.HIGH)
    GPIO.output(L_ForwardSignal, GPIO.LOW)
    GPIO.output(R_ForwardSignal, GPIO.LOW)
    GPIO.output(L_ReverseSignal, GPIO.LOW)
    GPIO.output(R_ReverseSignal, GPIO.LOW)
    while haltedScan() == "Obstacle Detected":
        time.sleep(scanTime)
    GPIO.output(L_HLight, GPIO.LOW)
    GPIO.output(R_HLight, GPIO.LOW)
    GPIO.output(L_Brake, GPIO.LOW)
    GPIO.output(R_Brake, GPIO.LOW)
    drive(direction, targetTime - traveledTime)

def scan(direction, traveledTime, targetTime): #Function for scanning Murphy's surroundings
    F_Distance = distance(F_US_Trig, F_US_Echo)
    R_Distance = distance(R_US_Trig, R_US_Echo)
    L_Distance = distance(L_US_Trig, L_US_Echo)
    B_Distance = distance(B_US_Trig, B_US_Echo)
    if ((F_Distance <= forwardDetectDist) or (R_Distance <= peripheralDetectDist) or (L_Distance <= peripheralDetectDist) or (B_Distance <= peripheralDetectDist)):
        print("Obstacle Detected")
        stop(direction, traveledTime, targetTime)

def haltedScan():
    F_Distance = distance(F_US_Trig, F_US_Echo)
    R_Distance = distance(R_US_Trig, R_US_Echo)
    L_Distance = distance(L_US_Trig, L_US_Echo)
    B_Distance = distance(B_US_Trig, B_US_Echo)
    if ((F_Distance <= forwardDetectDist) or (R_Distance <= peripheralDetectDist) or (L_Distance <= peripheralDetectDist) or (B_Distance <= peripheralDetectDist)):
        return "Obstacle Detected"
    else:
        return "Obstacle Not Found"

def endSuccess():
    GPIO.output(L_HLight, GPIO.HIGH)
    GPIO.output(R_HLight, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(L_HLight, GPIO.LOW)
    GPIO.output(R_HLight, GPIO.LOW)
    time.sleep(1)
    GPIO.output(L_HLight, GPIO.HIGH)
    GPIO.output(R_HLight, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(L_HLight, GPIO.LOW)
    GPIO.output(R_HLight, GPIO.LOW)

def endFailure():
    GPIO.output(L_Brake, GPIO.HIGH)
    GPIO.output(R_Brake, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(L_Brake, GPIO.LOW)
    GPIO.output(R_Brake, GPIO.LOW)
    time.sleep(1)
    GPIO.output(L_Brake, GPIO.HIGH)
    GPIO.output(R_Brake, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(L_Brake, GPIO.LOW)
    GPIO.output(R_Brake, GPIO.LOW)

if name == 'main': #Main function for primary code
    print("Murphy Ready. UNPLUG in 10...")
    time.sleep(1)
    for x in range(0, 9):
        print(x + "...")
        time.sleep(1)
    print("Murphy Starting")
    GPIO.output(L_HLight, GPIO.HIGH)
    GPIO.output(R_HLight, GPIO.HIGH)
    time.sleep(1)
    drive('F', 10.0)
    time.sleep(1)
    drive('L', 1.0)
    time.sleep(1)
    endSuccess()
    #Example functions for ultrasonic sensor functionality
    #try:
        #while True:
           # dist = distance(F_US_Trig, F_US_Echo)
          #  print("Measured Distance = %.1f cm" % dist)
           # time.sleep(1)

        # Reset by pressing CTRL + C
   # except KeyboardInterrupt:
     #   print("Measurement stopped by User")
       # GPIO.cleanup()