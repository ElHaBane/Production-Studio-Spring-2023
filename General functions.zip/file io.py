from dependents import *
# file that stores functions that can interact with text files

# writes a message into the passed path
def write_to_file(message, text_file_path="function_file.txt"): 
    writing_file = open(text_file_path, 'w')  # instantiates writing_file as the desired text file

    try:
        writing_file.write(message)  # stores the message using the text file
        writing_file.close()  # dealocates space in the memory
    
    # If an unexpected error occures while running the function
    except:
        writing_file.close()  # dealocates space in the memory


# returns the information from the passed path
# DEPENDENT: pathlib
def get_files_content(default_text="", text_file_path="function_file.txt"):  # returns the information from the passed path
    if pathlib.Path(text_file_path).is_file() == False:  # checks if the desired file exists
        print("Creating a new text file for the game...")  # prompts the user that a new file is being created
        write_to_file(default_text, text_file_path)  # creates the text file using the default_text
    
    reading_file = open(text_file_path, 'r')  # instantiates the reading_file as the desired text file

    try:
        files_content = reading_file.read()  # stores the files content into files_content
        reading_file.close()  # dealocates space in the memory
        return files_content  # returns the file's content

    # If an unexpected error occures while running the functino
    except:
        input("Error within get_files_content()")  # propts the user
        reading_file.close()  # dealocates space in the memory
        sys.exit()  # exits out of the program