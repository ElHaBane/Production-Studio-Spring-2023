from dependents import *
# file that stores functions strictly intended to display content

# displays a tuples elements in a numbered format
def display_numbered_elements(*options: str)->None:
    for option_i in range(len(options)):
        print(f"{option_i + 1}. {options[option_i]}")

# gives the user an error prompt and then closes the program
# DEPENDENT: sys
def display_error(error_message):
    input("ERROR:", error_message)
    sys.exit()

if __name__=='__main__':
    display_numbered_elements("he", "ho")