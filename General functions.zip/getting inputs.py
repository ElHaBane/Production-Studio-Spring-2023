from dependents import *
# file that stores functions used for retrieving user's inputs

# retrieves the user's input from a range of numbers
def get_integer_input(lowest_input: int, highest_input: int) -> int: 
    inputted_value = int(input("Enter input:")) # prompts the user
    # recursively calls itself if the inputted_value is NOT between the lowest input and the highest input
    return inputted_value if lowest_input <= inputted_value <= highest_input else get_integer_input(lowest_input, highest_input)


# gets a specific output using the index of the possible_outputs
# DEPENDENT: get_integer_input()
'''example:
possible_outputs = (2, 52, 19)

if the inputted value == 0: return 2
if the inputted value == 1: return 52
if the inputted value == 2: return 19'''
def get_designated_input_outputs(*possible_outputs: int) -> int:
    i = get_integer_input(0, len(possible_outputs) - 1)
    return possible_outputs[i]




if __name__ == '__main__':
    print()
