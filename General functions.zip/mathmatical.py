from dependents import *
# file that stores general mathmatical functions

# rectify info
def rectify(x): return max(0, x)
def drectify(x): return 1 if x > 0 else 0  # rectify derivative

# sigmoid info
# DEPENDANT: numpy
def sigmoid(x): return 1 / (1 + numpy.exp(-x)) 
def dsigmoid(x): return x * (1 - x)  # sigmoid derivative

# tangent derivative
# DEPENDANT: math
def dtanh(x): return 1 - pow(math.tanh(x), 2)

# step info
def step(x): return 1 if x > 0 else 0
def dstep(x): return 99999999999 if x == 0 else 0  # spet derivative